import {Component} from '@angular/core';
import {ROUTER_DIRECTIVES} from '@angular/router';

@component({
  templateUrl: 'app/transaction/transaction.component.html',
  directives:[ROUTER_DIRECTIVES]
  })
export class TransactionComponent {

}  
