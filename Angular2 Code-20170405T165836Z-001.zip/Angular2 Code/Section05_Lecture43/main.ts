import {bootstrap from} from '@angular/platform-browser-dynamic';
import {AppComponent} from './app.component';
import {LoggerService} from './util/logger.service';

bootstrap(AppComponent);
